HW08 - Matthew Kistner

This is a game called Shipwrecked where the goal is to avoid sharks and 
get treasure. 

The game can be controlled using the up, down, right, and left arrows which
will guide the sailor sprite off their ship, across the island, and 
to the treasure.

If you hit the boundary of the screen or the sharks you will be taken to 
a "you lose" screen. If you hit the treasure, you will be taken to a "win"
screen.

You can return to the home screen from all other screens if you hit the SELECT
button. 

The game will also tell you to WATCH OUT if you are near a shark and will tell
you that you are getting closer as you get closer to the treasure.

The game is fairly simple, but can be tricky if you do not maneuver correctly.

Look out for sharks and have fun. 