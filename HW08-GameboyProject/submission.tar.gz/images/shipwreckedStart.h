/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 shipwreckedStart shipwreckedStart.png 
 * Time-stamp: Wednesday 04/05/2023, 00:00:42
 * 
 * Image Information
 * -----------------
 * shipwreckedStart.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SHIPWRECKEDSTART_H
#define SHIPWRECKEDSTART_H

extern const unsigned short shipwreckedStart[38400];
#define SHIPWRECKEDSTART_SIZE 76800
#define SHIPWRECKEDSTART_LENGTH 38400
#define SHIPWRECKEDSTART_WIDTH 240
#define SHIPWRECKEDSTART_HEIGHT 160

#endif

