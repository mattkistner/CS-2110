/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 winScreen winScreen.png 
 * Time-stamp: Wednesday 04/05/2023, 02:23:25
 * 
 * Image Information
 * -----------------
 * winScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINSCREEN_H
#define WINSCREEN_H

extern const unsigned short winScreen[38400];
#define WINSCREEN_SIZE 76800
#define WINSCREEN_LENGTH 38400
#define WINSCREEN_WIDTH 240
#define WINSCREEN_HEIGHT 160

#endif

