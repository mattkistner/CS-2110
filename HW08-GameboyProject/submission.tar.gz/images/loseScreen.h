/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 loseScreen loseScreen.png 
 * Time-stamp: Wednesday 04/05/2023, 02:32:26
 * 
 * Image Information
 * -----------------
 * loseScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSESCREEN_H
#define LOSESCREEN_H

extern const unsigned short loseScreen[38400];
#define LOSESCREEN_SIZE 76800
#define LOSESCREEN_LENGTH 38400
#define LOSESCREEN_WIDTH 240
#define LOSESCREEN_HEIGHT 160

#endif

