/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 islandPlay islandPlay.png 
 * Time-stamp: Wednesday 04/05/2023, 00:10:06
 * 
 * Image Information
 * -----------------
 * islandPlay.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ISLANDPLAY_H
#define ISLANDPLAY_H

extern const unsigned short islandPlay[38400];
#define ISLANDPLAY_SIZE 76800
#define ISLANDPLAY_LENGTH 38400
#define ISLANDPLAY_WIDTH 240
#define ISLANDPLAY_HEIGHT 160

#endif

