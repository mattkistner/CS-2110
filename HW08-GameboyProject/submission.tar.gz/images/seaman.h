/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x40 seaman seaman.jpeg 
 * Time-stamp: Wednesday 04/05/2023, 01:12:49
 * 
 * Image Information
 * -----------------
 * seaman.jpeg 30@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SEAMAN_H
#define SEAMAN_H

extern const unsigned short seaman[1200];
#define SEAMAN_SIZE 2400
#define SEAMAN_LENGTH 1200
#define SEAMAN_WIDTH 30
#define SEAMAN_HEIGHT 40

#endif

